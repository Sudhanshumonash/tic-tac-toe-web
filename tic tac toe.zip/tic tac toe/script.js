function initializeGame() {
    let currentPlayer = 'X';
    let gameBoard = Array(9).fill(null);
    let gameOver = false;

    const cells = document.querySelectorAll('.tic1');
    cells.forEach((cell, index) => {
        cell.addEventListener('click', () => {
            if (!gameOver && !cell.textContent) {
                gameBoard[index] = currentPlayer;
                cell.textContent = currentPlayer;
                cell.classList.add(currentPlayer === 'X' ? 'player-x' : 'player-o');
                if (checkWin(gameBoard, currentPlayer)) {
                    if (currentPlayer === 'X') {
                        showNotification('X player🗿 O player🤡');
                    } else {
                        showNotification(`Player ${currentPlayer} wins!`);
                    }
                    gameOver = true;
                } else if (gameBoard.every(cell => cell !== null)) {
                    showNotification("It's a draw!");
                    gameOver = true;
                } else {
                    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
                }
            }
        });
    });

    document.querySelector('.reset1').addEventListener('click', resetGame);
    document.querySelector('#reset').addEventListener('click', resetGame);

    function resetGame() {
        gameBoard.fill(null);
        cells.forEach(cell => {
            cell.textContent = '';
            cell.classList.remove('player-x', 'player-o');
        });
        currentPlayer = 'X';
        gameOver = false;
    }
}

function checkWin(board, player) {
    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], 
        [0, 3, 6], [1, 4, 7], [2, 5, 8], 
        [0, 4, 8], [2, 4, 6]             
    ];

    return winPatterns.some(pattern => 
        pattern.every(index => board[index] === player)
    );
}

function showNotification(message) {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.style.display = 'block';

    notification.style.animation = 'fadeInOut 5s';

    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

document.addEventListener('DOMContentLoaded', initializeGame);
